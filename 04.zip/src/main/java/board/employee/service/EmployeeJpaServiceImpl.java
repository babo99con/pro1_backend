package board.employee.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import board.employee.jpa.EmployeeEntity;
import board.employee.jpa.EmployeeRepository;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class EmployeeJpaServiceImpl implements EmployeeJpaService {

    private final EmployeeRepository employeeRepository;

    @Override
    public List<EmployeeEntity> getEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public List<EmployeeEntity> getEmployeesByCondition(String condition, String value) {
        
        if (condition == null || condition.trim().isEmpty()) {
            throw new IllegalArgumentException("condition is required.");
        }

        if (value == null || value.trim().isEmpty()) {
            List<EmployeeEntity> list = new ArrayList<>();
            return list;
        }

        String key = condition.toLowerCase().trim();
        
        if (key.equals("name")) {
            List<EmployeeEntity> list = employeeRepository.searchByName(value);
            
            return list;
        }
        if (key.equals("department")) {
            List<EmployeeEntity> list = employeeRepository.searchByDepartment(value);
            
            return list;
        }
        if (key.equals("employeeid")) {
            Optional<EmployeeEntity> optional = employeeRepository.searchByEmployeeId(value);
            
            if(optional.isPresent())
            {
                List<EmployeeEntity> list = new ArrayList<>();
                list.add(optional.get());
                return list;
                
            }
        }

        throw new IllegalArgumentException("Unsupported condition: " + condition);
    }

    @Override
    public EmployeeEntity getEmployee(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public EmployeeEntity createEmployee(EmployeeEntity newEmployee) {
        if (newEmployee.getEmployeeId() == null || newEmployee.getEmployeeId().trim().isEmpty()) {
            throw new IllegalArgumentException("employeeId is required.");
        }

        boolean duplicateId = employeeRepository.searchByEmployeeId(newEmployee.getEmployeeId()).isPresent();
        if (duplicateId) {
            throw new IllegalArgumentException("employeeId already exists.");
        }

        return employeeRepository.save(newEmployee);
    }

    @Override
    public EmployeeEntity updateEmployee(Long id, EmployeeEntity newEmployee) {
        EmployeeEntity oldEmployee = employeeRepository.findById(id).orElse(null);
        
        if (oldEmployee == null) {
            return null;
        }

        String newEmployeeId = newEmployee.getEmployeeId();
        
        if (newEmployeeId != null && !newEmployeeId.trim().isEmpty()) {
            var found = employeeRepository.searchByEmployeeId(newEmployeeId).orElse(null);
    
            if (found != null && !found.getId().equals(id)) {
                throw new IllegalArgumentException("employeeId already exists.");
            }
        }


        oldEmployee.update(newEmployee);

        return employeeRepository.save(oldEmployee);
    }

    @Override
    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }
}
